    parser.add_argument(
        "--timesteps", type=int, default=50,
        help="denoising 步数，不传则使用训练时的 diffusion_steps")
    parser.add_argument(
        "--resamplings", type=int, default=10,
        help="denoising 步数，不传则使用训练时的 diffusion_steps")

        if s <= 10 and s>=5 and u < 1 and True:
        resamplings = resamplings+1